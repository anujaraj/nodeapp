# toodm
Simple to-do webapp using nodejs
This repo is just a practice of my skills of NodeJS and ExpressJS connecting with the SQL Server and serving a simple webpage using authentication. This project is a collaboration of me and my friend Anuja.

To clone and use:
  1. Download the zip file.
  2. Navigate to the folder containing the app.js file in you terminal (Windows/Ubuntu).
  3. Enter the command: node app.js (node must be installed)
  4. Open a browser and go to http://localhost:3000/login to begin.
