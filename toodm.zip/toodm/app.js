// Importing and adding variables
var express = require('express');
var bodyParser = require('body-parser');
var sessions = require('express-session');
var session;
var app = express();
var mysql      = require('mysql');


// Adding middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
app.use(sessions({
    secret: "SESS_SECRET",
    resave: false,
    saveUninitialized: true,
    name: "SESS_NAME",
    cookie: {
        maxAge: SESS_LIFETIME,
        sameSite: true,
        secure: IN_PROD /* Strict */
    }
}));

// Connection
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'todo'
  });
  connection.connect(function(err){
  if(!err) {
      console.log("Database is connected");
  } else {
      console.log("Error while connecting with database");
  }
  });
  



// Routing
app.get('/login', function(req,resp) {
    session = req.session;
    if(session.uniqueID) {
        resp.redirect('/redirects');
    }
    resp.sendFile('./views/index.html', {root: __dirname});
});
app.get('/signup', function(req,resp) {
    session = req.session;
    if(session.uniqueID) {
        resp.redirect('/redirects');
    }
    resp.sendFile('./views/index.html', {root: __dirname});
});
app.get('/todo', function(req,resp) {
    session = req.session;
    if(session.uniqueID) {
        resp.redirect('/redirects');
    }
    resp.sendFile('./views/todo.html', {root: __dirname});
});

app.post('/addtask', function(req,resp) {
    var todos={
        "todo":req.body.newtask,
    
        
    }
    connection.query('INSERT INTO todos SET ?',todos, function (error, results, fields) {
      if (error) {
        resp.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
       
        connection.query("SELECT * FROM todos", function (err, result, fields) {
            if (err) throw err;
            console.log(result);
            
          });
        }
      
   
    })
    resp.sendFile('./views/todo.html', {root: __dirname});
});


app.post('/removetask', function(req,resp) {
    var todos={
        "todo":req.body.removetask,
    
        
    }
    connection.query('DELETE FROM todos WHERE todo= ?', [req.body.removetask], function(err, result) {
        if (err) {
            throw err;
        }
      
    
      });
    resp.sendFile('./views/todo.html', {root: __dirname});
});





app.post('/login',function(req,resp) {
    // resp.end(JSON.stringify(req.body));
    // session = req.session;
    // if(session.uniqueID) {
    //     req.redirect('/redirects');
    // }
    // if(req.body.username=='admin' && req.body.password=='admin') {
    //     session.uniqueID = req.body.username;
    // }
    
    
        var data = {
    username: req.body.username,
    password: req.body.password
     };

var user = data[0],
    pass = data[1];

connection.query('SELECT username, password FROM users WHERE username = ? AND password = ?', [user], [pass], function(err, results) {
    if(results) {
    req.session.regenerate(function() {
        req.session.login = true;
        req.session.username = req.body.username;
        res.redirect('/redirects');
        });
    } 
});

    resp.redirect('/redirects');
});

app.post('/signup', function(req,resp) {
    var users={
        "name":req.body.name,
        "username":req.body.username,
        "password":req.body.password,
        
    }
    connection.query('INSERT INTO users SET ?',users, function (error, results, fields) {
      if (error) {
        resp.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
          resp.json({
            status:true,
            data:results,
            message:'user registered sucessfully'
        })
      }

    })
    resp.sendFile('./views/index.html', {root: __dirname});
});




app.get('/logout', function(req, resp) {
    req.session.destroy();
    resp.redirect('/login');
});

app.get('/download', function(req, resp) {
    resp.download('./views/index.html');
});

app.get('/redirects', function(req, resp) {
    session = req.session;
    if(session.uniqueID) {
        resp.end("You are logged in!!");
    } else{
    resp.send('Who Are You? <a href="/logout">Kill session</a>')}
});

app.listen(3000, function() {
    console.log("Listening at port 3000");
    console.log("Server started at http://127.0.0.1:3000");
});